package br.com.fiap.gyma_api.model;

public enum MuscleGroup {
    Peito,
    Triceps,
    Costas,
    Biceps,
    Ombro,
    Abdomen,
    Perna,
    Panturrilha
}
