import Navbar from "@/components/navbar";

export default function CheckInPage(){

    return(
        <>
            <Navbar active="Check-in"/>
        </>
    )
}