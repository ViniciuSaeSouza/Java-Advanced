package br.com.fiap.SecurityBasic.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Tranquilo")
public class HttpController {

    @GetMapping("/public")
    String publicRoute() {
        return "<h1>Calma! É uma rota Pública. Fique Tranquilo! </h1>";
    }

    @GetMapping("/private")
    String privateRoute() {
        return "<h1>É uma rota Privada. Somente pessoas autorizadas pelo Tranquilo! </h1>";
    }

}
