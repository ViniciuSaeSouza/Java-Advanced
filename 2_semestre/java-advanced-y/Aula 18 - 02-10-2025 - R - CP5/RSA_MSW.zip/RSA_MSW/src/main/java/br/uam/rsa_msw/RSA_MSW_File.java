/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.uam.rsa_msw;

/**
 *
 * @author MSWagner
 */

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.math.BigInteger;

public class RSA_MSW_File {

    public static void main(String args[]) {
        // Ler a mensagem do arquivo
        String msg = readMessageFromFile("C:\\Users\\MSWagner\\Documents\\NetBeansProjects\\RSA_MSW\\src\\main\\java\\br\\uam\\rsa_msw\\mensagem.txt");
        String msgcifrada = null;
        String msgdecifrada = null;

        // Definindo valores para o RSA
        BigInteger p = new BigInteger("17");
        BigInteger q = new BigInteger("23");
        BigInteger n = p.multiply(q);
        BigInteger e = new BigInteger("3");
        BigInteger m = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        BigInteger d = e.modInverse(m);

        System.out.println("p:" + p);
        System.out.println("q:" + q);
        System.out.println("n:" + n);
        System.out.println("e:" + e);
        System.out.println("d:" + d);

        // Mensagem cifrada - RSA_encrypt()
        byte[] msgBytes = msg.getBytes(StandardCharsets.US_ASCII);

        StringBuilder cifradaStringBuilder = new StringBuilder();
        for (byte b : msgBytes) {
            BigInteger msgBigInt = new BigInteger(new byte[] { b });
            BigInteger cifrada = msgBigInt.modPow(e, n);
            cifradaStringBuilder.append(cifrada).append(" ");
        }
        msgcifrada = cifradaStringBuilder.toString().trim();

        System.out.println("msg cifrada: " + msgcifrada);

        // Mensagem decifrada - RSA_decrypt()
        String[] cifradaParts = msgcifrada.split(" ");
        StringBuilder decifradaStringBuilder = new StringBuilder();
        for (String part : cifradaParts) {
            BigInteger cifradaBigInt = new BigInteger(part);
            BigInteger decifrada = cifradaBigInt.modPow(d, n);
            decifradaStringBuilder.append((char) decifrada.byteValueExact());
        }
        msgdecifrada = decifradaStringBuilder.toString();

        System.out.println("msg decifrada: " + msgdecifrada);
    }

    private static String readMessageFromFile(String filename) {
        try {
            byte[] bytes = Files.readAllBytes(Paths.get(filename));
            return new String(bytes, StandardCharsets.US_ASCII);
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
            return "";
        }
    }
}
