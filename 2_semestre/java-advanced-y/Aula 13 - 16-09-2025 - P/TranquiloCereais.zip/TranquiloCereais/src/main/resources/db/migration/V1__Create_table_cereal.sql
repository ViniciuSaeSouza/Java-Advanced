CREATE TABLE cereal (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        preco DECIMAL(10,2) NOT NULL
);

INSERT INTO cereal (nome, preco) VALUES ('Arroz', 5.50);
INSERT INTO cereal (nome, preco) VALUES ('Feijão', 7.20);
INSERT INTO cereal (nome, preco) VALUES ('Milho', 4.00);
