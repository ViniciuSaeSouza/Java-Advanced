package model;

public class Cereal {
    private Integer id;
    private String nome;
    private Double preco;

    public Cereal(Integer id, String nome, Double preco) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }

    public Cereal(String nome, Double preco) {
        this(null, nome, preco);
    }

    public Integer getId() { return id; }
    public String getNome() { return nome; }
    public Double getPreco() { return preco; }

    @Override
    public String toString() {
        return "Cereal{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", preco=" + preco +
                '}';
    }
}
