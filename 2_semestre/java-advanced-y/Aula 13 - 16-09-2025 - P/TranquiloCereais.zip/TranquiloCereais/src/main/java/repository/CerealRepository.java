package repository;

import config.DatabaseConfig;
import model.Cereal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CerealRepository {

    public void salvar(Cereal cereal) {
        String sql = "INSERT INTO cereal (nome, preco) VALUES (?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cereal.getNome());
            stmt.setDouble(2, cereal.getPreco());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar cereal", e);
        }
    }

    public List<Cereal> listarTodos() {
        List<Cereal> cereais = new ArrayList<>();
        String sql = "SELECT id, nome, preco FROM cereal";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                cereais.add(new Cereal(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getDouble("preco")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar cereais", e);
        }
        return cereais;
    }
}
