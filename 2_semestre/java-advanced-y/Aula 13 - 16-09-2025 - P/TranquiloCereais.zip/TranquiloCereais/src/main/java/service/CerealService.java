package service;

import model.Cereal;
import repository.CerealRepository;

import java.util.List;

public class CerealService {
    private final CerealRepository repository;

    public CerealService() {
        this.repository = new CerealRepository();
    }

    public void adicionarCereal(String nome, Double preco) {
        repository.salvar(new Cereal(nome, preco));
    }

    public List<Cereal> listarCereais() {
        return repository.listarTodos();
    }
}
