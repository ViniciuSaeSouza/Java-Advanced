
import model.Cereal;
import service.CerealService;

import java.util.List;

public class MainApp {
    public static void main(String[] args) {
        CerealService service = new CerealService();

        System.out.println("== Lista inicial de cereais (do Flyway) ==");
        List<Cereal> lista = service.listarCereais();
        lista.forEach(System.out::println);

        System.out.println("\n== Adicionando um novo cereal ==");
        service.adicionarCereal("Aveia", 6.30);

        lista = service.listarCereais();
        lista.forEach(System.out::println);
    }
}
