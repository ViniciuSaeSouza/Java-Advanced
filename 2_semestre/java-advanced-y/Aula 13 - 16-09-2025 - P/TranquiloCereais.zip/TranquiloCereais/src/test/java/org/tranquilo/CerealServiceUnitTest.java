package org.tranquilo;

/*
 Teste Unitário puro: - não acessa banco nem infraestrutura externa;
                      - testa apenas as regras de negócio em memória.

 Aqui não precisamos do banco de dados — vamos simular (mockar) o repositório.
 CerealServiceUnitTest → Teste Unitário puro (usa mock do repositório com Mockito, sem banco).

 - JUnit 5 para organizar e executar os testes.
 - Mockito para criar mocks e simular dependências (sem precisar de banco real).
 - Surefire Plugin garantindo que os testes rodam 100% integrados com o Maven.

 Se algum comportamento estiver errado, o JUnit falhará e mostrará a mensagem de erro.
 */

import model.Cereal;
import repository.CerealRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CerealServiceUnitTest {

    private CerealRepository mockRepo;
    private CerealService service;

    @BeforeEach
    void setUp() {
        // Criamos um mock do repository para não acessar o banco
        mockRepo = Mockito.mock(CerealRepository.class);
        service = new CerealService() {
            @Override
            public List<Cereal> listarCereais() {
                return mockRepo.listarTodos();
            }

            @Override
            public void adicionarCereal(String nome, Double preco) {
                if (preco <= 0) throw new IllegalArgumentException("Preço deve ser maior que zero.");
                mockRepo.salvar(new Cereal(nome, preco));
            }
        };
    }

    @Test
    void testNaoPermitePrecoZeroOuNegativo() {
        assertThrows(IllegalArgumentException.class,
                () -> service.adicionarCereal("Cevada", 0.0));

        assertThrows(IllegalArgumentException.class,
                () -> service.adicionarCereal("Soja", -5.0));
    }

    @Test
    void testListarCereaisMockados() {
        // Arrange: configuramos o mock para retornar uma lista fake
        when(mockRepo.listarTodos()).thenReturn(Arrays.asList(
                new Cereal(1, "Arroz", 5.50),
                new Cereal(2, "Feijão", 7.20)
        ));

        // Act
        List<Cereal> cereais = service.listarCereais();

        // Assert
        assertEquals(2, cereais.size());
        assertEquals("Arroz", cereais.get(0).getNome());
    }
}
