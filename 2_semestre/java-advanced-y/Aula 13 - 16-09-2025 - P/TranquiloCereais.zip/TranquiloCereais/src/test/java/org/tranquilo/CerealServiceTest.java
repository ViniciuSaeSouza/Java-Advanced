package org.tranquilo;

/*
 Teste de Integração: conecta no banco (H2) e valida inserção/listagem.

 Teste unitário via JUnit5 para teste do service:
 ✅ testAdicionarCereal → confirma que salvar funciona.
 ✅ testListarCereaisIniciais → confirma que os dados do Flyway foram aplicados.

 Se algum comportamento estiver errado, o JUnit falhará e mostrará a mensagem de erro.
 */

import model.Cereal;
import service.CerealService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CerealServiceTest {

    private CerealService service;

    @BeforeEach
    void setUp() {
        // Arrange: cria nova instância do serviço
        service = new CerealService();
    }

    @Test
    void testAdicionarCereal() {
        // Act: adiciona um cereal
        service.adicionarCereal("Trigo", 8.50);

        // Assert: verifica se ele aparece na lista
        List<Cereal> cereais = service.listarCereais();
        assertTrue(cereais.stream().anyMatch(c -> "Trigo".equals(c.getNome())));
    }

    @Test
    void testListarCereaisIniciais() {
        // Act: obtém lista (já vem do Flyway)
        List<Cereal> cereais = service.listarCereais();

        // Assert: deve conter pelo menos os inseridos na migration
        assertTrue(cereais.stream().anyMatch(c -> "Arroz".equals(c.getNome())));
        assertTrue(cereais.stream().anyMatch(c -> "Feijão".equals(c.getNome())));
        assertTrue(cereais.stream().anyMatch(c -> "Milho".equals(c.getNome())));
    }
}
