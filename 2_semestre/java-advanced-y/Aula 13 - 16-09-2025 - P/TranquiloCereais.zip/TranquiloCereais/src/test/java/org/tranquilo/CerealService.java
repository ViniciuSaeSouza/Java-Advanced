package org.tranquilo;

/*
 Teste Unitário puro: - não acessa banco nem infraestrutura externa;
                      - testa apenas as regras de negócio em memória.

 Aqui não precisamos do banco de dados — vamos simular (mockar) o repositório.

 Se algum comportamento estiver errado, o JUnit falhará e mostrará a mensagem de erro.
 */

import model.Cereal;
import repository.CerealRepository;

import java.util.List;

public class CerealService {
    private final CerealRepository repository;

    public CerealService() {
        this.repository = new CerealRepository();
    }

    public void adicionarCereal(String nome, Double preco) {
        if (preco <= 0) {
            throw new IllegalArgumentException("Preço deve ser maior que zero.");
        }
        repository.salvar(new Cereal(nome, preco));
    }

    public List<Cereal> listarCereais() {
        return repository.listarTodos();
    }
}
