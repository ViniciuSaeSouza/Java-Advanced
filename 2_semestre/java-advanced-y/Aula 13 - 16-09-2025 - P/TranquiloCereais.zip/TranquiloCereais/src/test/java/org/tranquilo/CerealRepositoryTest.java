package org.tranquilo;

import model.Cereal;
import repository.CerealRepository;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CerealRepositoryTest {

    @Test
    void testListarTodos() {
        CerealRepository repo = new CerealRepository();
        List<Cereal> cereais = repo.listarTodos();
        assertFalse(cereais.isEmpty());
    }

    @Test
    void testSalvar() {
        CerealRepository repo = new CerealRepository();
        repo.salvar(new Cereal("Quinoa", 12.50));
        List<Cereal> cereais = repo.listarTodos();

        assertTrue(cereais.stream().anyMatch(c -> "Quinoa".equals(c.getNome())));
    }
}
