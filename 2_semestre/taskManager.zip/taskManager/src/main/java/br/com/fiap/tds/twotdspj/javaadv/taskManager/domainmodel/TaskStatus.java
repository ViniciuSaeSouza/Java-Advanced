package br.com.fiap.tds.twotdspj.javaadv.taskManager.domainmodel;

public enum TaskStatus {
    PENDING, IN_PROGRESS, COMPLETED
}
